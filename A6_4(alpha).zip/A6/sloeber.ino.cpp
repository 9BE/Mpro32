#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2020-02-11 19:08:43

#include "Arduino.h"
#include "Arduino.h"
#include "LReader.h"
#include "Mando.h"
#include "Lantern.h"
#include "JsonHandler.h"
#include "LocSpiff.h"
#include "ServerTempatan.h"
#include <driver/adc.h>
#include "timing.h"
#include "board.h"
#include "LocWiFi.h"
#include "esp_task_wdt.h"

void setup() ;
void loop() ;
inline void getVcc() ;
void mainLampu(uint16_t berapaKali, uint64_t delayTime) ;
void mainPower() ;
float rollAverage(float prev, float newData, float roll) ;
inline void setupSPIFFiles(bool freshSetup) ;
inline void espReboot() ;
inline void urusAlert() ;
inline void urusConfig() ;
inline void urusAIS() ;

#include "A6.ino"


#endif
